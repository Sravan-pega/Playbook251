export const configProps = {
  width: '100%',
  height: 'auto',
  autoplay: false,
  muted: false,
  loop: false,
  testId: 'pega-field-video'
};

export const configPropsAutoplay = {
  ...configProps,
  autoplay: true,
  muted: true,
  datapageparams: 'videoId:autoplay-video'
};

export const configPropsResponsive = {
  ...configProps,
  datapageparams: 'videoId:responsive-video'
};

export const configPropsWithDataPage = {
  ...configProps,
  datapage: 'D_VideoData',
  datapageparams: 'videoId:default-video'
};
