import { useState, useEffect, useCallback } from 'react';
import { withConfiguration } from '@pega/cosmos-react-core';

import type { PConnFieldProps } from '../shared/PConnProps';
import '../shared/create-nonce';

import StyledPegaFieldVideoWrapper from './styles';

// interface for props
interface PegaFieldVideoProps extends Partial<PConnFieldProps> {
  getPConnect?: () => any;
  width?: string | number;
  height?: string | number;
  autoplay?: boolean;
  muted?: boolean;
  loop?: boolean;
  datapage?: string;
  datapageparams?: string;
  testId?: string;
}

// Interface for data page response
interface DataPageVideoData extends Partial<PegaFieldVideoProps> {
  videoSource: string;
}

// Default fallback video data for Storybook
const DEFAULT_FALLBACK_VIDEOS = {
  default: 'https://www.w3schools.com/html/mov_bbb.mp4',
  autoplay: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/ForBiggerBlazes.mp4',
  responsive: 'https://commondatastorage.googleapis.com/gtv-videos-bucket/sample/Sintel.mp4'
};

function PegaFieldVideo(props: PegaFieldVideoProps) {
  const {
    getPConnect,
    width = '100%',
    height = 'auto',
    autoplay = false,
    muted = false,
    loop = false,
    testId,
    datapage,
    datapageparams
  } = props;

  const [videoData, setVideoData] = useState<DataPageVideoData | null>(null);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  // Safely get PConnect - it might not exist in Storybook
  let pConn: any = null;
  try {
    pConn = getPConnect && typeof getPConnect === 'function' ? getPConnect() : null;
  } catch {
    pConn = null;
  }

  const isStorybookEnvironment =
    !pConn || !getPConnect || typeof getPConnect !== 'function' || !(window as any).PCore;

  const parseDataPageParams = useCallback(
    (params: string | undefined): Record<string, any> => {
      if (!params) return {};
      try {
        const getParamValue = (e: string) => {
          if (e === null || e === '') return e;
          const eachVal = e.split(':');
          if (eachVal[1].trim().startsWith('.')) {
            let propVal = eachVal[1].trim();
            const lastIndex = propVal.lastIndexOf('.');
            if (lastIndex === 0) {
              propVal = pConn.getValue(propVal);
            } else {
              const searchProp = propVal.substring(lastIndex);
              propVal = pConn.getValue(
                searchProp,
                `caseInfo.content${propVal.substring(0, lastIndex)}`
              );
            }
            return `${JSON.stringify(eachVal[0].trim())}:${JSON.stringify(propVal)}`;
          }
          return `${JSON.stringify(eachVal[0].trim())}:${JSON.stringify(eachVal[1].trim())}`;
        };
        const dPageParams = `{${params.split(',').map(getParamValue).join(',')}}`;
        return JSON.parse(dPageParams);
      } catch {
        return {};
      }
    },
    [pConn]
  );

  const getStorybookFallbackData = useCallback(
    (_dp: string, params: string | undefined): DataPageVideoData => {
      const parsedParams = parseDataPageParams(params);
      let videoSource = DEFAULT_FALLBACK_VIDEOS.default;
      if (parsedParams.videoId === 'autoplay-video') {
        videoSource = DEFAULT_FALLBACK_VIDEOS.autoplay;
      } else if (parsedParams.videoId === 'responsive-video') {
        videoSource = DEFAULT_FALLBACK_VIDEOS.responsive;
      }
      return {
        videoSource,
        width: parsedParams.width ?? width,
        height: parsedParams.height ?? height,
        autoplay: parsedParams.autoplay ?? autoplay,
        muted: parsedParams.muted ?? muted,
        loop: parsedParams.loop ?? loop
      };
    },
    [parseDataPageParams, width, height, autoplay, muted, loop]
  );

  const fetchVideoData = useCallback(async () => {
    if (!datapage) return;

    if (isStorybookEnvironment) {
      setVideoData(getStorybookFallbackData(datapage, datapageparams));
      return;
    }

    if (!pConn) return;

    setLoading(true);
    setError(null);

    try {
      const PCore = (window as any).PCore;
      if (!PCore) throw new Error('PCore not available');

      const params = parseDataPageParams(datapageparams);
      const dataPageResponse = await PCore.getDataPageUtils().getPageDataAsync(
        datapage,
        pConn.getContextName && pConn.getContextName(),
        params
      );

      const responseData = dataPageResponse?.data ?? dataPageResponse;
      if (responseData) {
        setVideoData(responseData);
      } else {
        throw new Error('No data returned from data page');
      }
    } catch (err) {
      setError(`Failed to load video data: ${err instanceof Error ? err.message : 'Unknown error'}`);
    } finally {
      setLoading(false);
    }
  }, [datapage, datapageparams, pConn, isStorybookEnvironment, getStorybookFallbackData, parseDataPageParams]);

  useEffect(() => {
    if (datapage) {
      fetchVideoData();
    } else if (isStorybookEnvironment) {
      setVideoData(getStorybookFallbackData('D_VideoData', undefined));
    }
  }, [datapage, fetchVideoData, isStorybookEnvironment, getStorybookFallbackData]);

  if (!datapage && !isStorybookEnvironment) {
    return (
      <StyledPegaFieldVideoWrapper data-testid={testId}>
        <div className='no-video-message'>No data page configured</div>
      </StyledPegaFieldVideoWrapper>
    );
  }

  if (loading) {
    return (
      <StyledPegaFieldVideoWrapper data-testid={testId}>
        <div className='loading-message'>Loading video…</div>
      </StyledPegaFieldVideoWrapper>
    );
  }

  if (error) {
    return (
      <StyledPegaFieldVideoWrapper data-testid={testId}>
        <div className='error-message'>{error}</div>
      </StyledPegaFieldVideoWrapper>
    );
  }

  const {
    videoSource = '',
    width: dataWidth = width,
    height: dataHeight = height,
    autoplay: dataAutoplay = autoplay,
    muted: dataMuted = muted,
    loop: dataLoop = loop
  } = videoData ?? {};

  if (!videoSource) {
    return (
      <StyledPegaFieldVideoWrapper data-testid={testId}>
        <div className='no-video-message'>No video source provided from data page</div>
      </StyledPegaFieldVideoWrapper>
    );
  }

  return (
    <StyledPegaFieldVideoWrapper data-testid={testId}>
      <video
        controls
        width={dataWidth}
        height={dataHeight}
        autoPlay={dataAutoplay}
        muted={dataMuted}
        loop={dataLoop}
        className='video-player'
      >
        <source src={videoSource} type='video/mp4' />
        <source src={videoSource} type='video/webm' />
        <source src={videoSource} type='video/ogg' />
        <track kind='captions' src='' srcLang='en' label='English' />
        Your browser does not support the video tag.
      </video>
    </StyledPegaFieldVideoWrapper>
  );
}

export default withConfiguration(PegaFieldVideo);
